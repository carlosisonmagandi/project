package com.accenture.ws.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="order_table")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false, updatable = false)
    long id;

    String orderName;
    double price;
    boolean isDiscounted;
    double isDiscountPercentage = 0.5;


    public Order() {
    }

    public Order(String orderName, double price, boolean isDiscounted){
    this.orderName = orderName;
    this.price = price;
    this.isDiscounted = isDiscounted;
}

    public long getId() {
        return id;
    }

    public String getOrderName() {
        return orderName;
    }

    public double getPrice() {
        return price;
    }

    public boolean getIsDiscounted() {
        return isDiscounted;
    }

    public double getIsDiscountPercentage() {
        return isDiscountPercentage;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setIsDiscounted(boolean discounted) {
        isDiscounted = discounted;
    }

    public void setIsDiscountPercentage(double isDiscountPercentage) {
        this.isDiscountPercentage = isDiscountPercentage;
    }
}
