package com.accenture.ws.entity;

import java.util.List;

public class OrderBilling {
    List<Order> orderList;
    CafeClerk clerk;

    public List<Order> getOrderList() {
        return orderList;
    }

    public CafeClerk getClerk() {
        return clerk;
    }

    public void setOrderList(List<Order> orderList) {
        this.orderList = orderList;
    }

}

