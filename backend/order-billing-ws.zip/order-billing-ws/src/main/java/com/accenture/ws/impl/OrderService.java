package com.accenture.ws.impl;

import com.accenture.ws.entity.Order;
import com.accenture.ws.repository.BillingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    private final BillingRepository billingRepository;

    public OrderService(BillingRepository billingRepository) {
        this.billingRepository = billingRepository;
    }

    public List<Order> getOrderList() {
        return billingRepository.findAll();
    }



    public Order addOrder(Order order) {
        return billingRepository.save(order);
    }

    public void deleteOrder(Long id){
        billingRepository.deleteById(id);
    }

    public Order updateOrder(Order order) {
        billingRepository.findById(order.getId());
        return billingRepository.save(order);
    }



}
