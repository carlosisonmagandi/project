package com.accenture.ws.controller;

import com.accenture.ws.entity.Order;
import com.accenture.ws.impl.OrderService;
import com.accenture.ws.repository.BillingRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class BillingController {

    private final OrderService orderService;
    private final BillingRepository billingRepository;

    public BillingController(OrderService orderService, BillingRepository billingRepository){
        this.orderService=orderService;
        this.billingRepository = billingRepository;
    }

    @GetMapping("/orders")
    public List<Order> orderList() {
        return orderService.getOrderList();
    }

    @PostMapping("/orders")
    public Order addOrder(@RequestBody Order order) {
        return orderService.addOrder(order);
    }
//
//    @PostMapping("/orders")
//    public Order addOrder(@RequestBody Order order) {
//        return billingRepository.save(order);
//    }



    @DeleteMapping("orders/{id}")
    public void deleteOrder(@PathVariable("id") Long id) {
        orderService.deleteOrder(id);
    }

    @PutMapping("/orders")
    public Order updateOrder(@RequestBody Order order) {
        return orderService.updateOrder(order);
    }

}
