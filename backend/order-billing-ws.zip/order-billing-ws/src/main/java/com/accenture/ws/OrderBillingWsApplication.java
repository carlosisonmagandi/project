package com.accenture.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderBillingWsApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderBillingWsApplication.class, args);
	}

}
