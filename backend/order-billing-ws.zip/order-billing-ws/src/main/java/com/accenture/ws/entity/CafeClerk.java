package com.accenture.ws.entity;

public class CafeClerk {
    String name="Carlo";

    public String getName() {
        return name;
    }
}
