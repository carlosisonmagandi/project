package com.accenture.ws.impl;

public class DiscountedBill {


}
