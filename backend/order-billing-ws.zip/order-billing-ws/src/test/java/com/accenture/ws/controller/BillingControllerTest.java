package com.accenture.ws.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BillingControllerTest {

    @Test
    void orderList() {
    }

    @Test
    void addOrder() {
    }

    @Test
    void deleteOrder() {
    }

    @Test
    void updateOrder() {
    }
}