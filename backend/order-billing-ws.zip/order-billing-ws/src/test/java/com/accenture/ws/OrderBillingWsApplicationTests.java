package com.accenture.ws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderBillingWsApplicationTests {

	@Test
	void contextLoads() {
	}

}
