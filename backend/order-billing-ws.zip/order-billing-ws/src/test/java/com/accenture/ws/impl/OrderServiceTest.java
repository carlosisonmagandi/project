package com.accenture.ws.impl;


import com.accenture.ws.repository.BillingRepository;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.core.annotation.Order;
import org.springframework.test.annotation.Rollback;

import java.util.List;

@DataJpaTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class OrderServiceTest {

    private TestEntityManager entityManager;
    @Autowired
    private BillingRepository ordersRepository;

    @Test
    @Order(1)
    public void getOrderList() {
        List<com.accenture.ws.entity.Order> orders = (List<com.accenture.ws.entity.Order>) ordersRepository.findAll();
        Assertions.assertThat(orders.size()).isGreaterThan(0);
    }

    @Test
    @Order(2)
    @Rollback(false)
    public void addOrder() {
        com.accenture.ws.entity.Order order = ordersRepository.save(new com.accenture.ws.entity.Order("Cafe Latte",3.5,true));
        Assertions.assertThat(order.getId()).isGreaterThan(0);
    }


    @Test
    public void deleteOrder() {
//        List<com.accenture.ws.entity.Order> orders = (List<com.accenture.ws.entity.Order>) ordersRepository.findAll();
//
//       Order ord = null;
//        ordersRepository.findById();
//        ordersRepository.deleteById();
//        List<com.accenture.ws.entity.Order> orders2 = (List<com.accenture.ws.entity.Order>) ordersRepository.findAll();
//        Assertions.assertThat(orders2.size() < orders.size());

    }

    @Test
    @Order(2)
    @Rollback(false)
    public void updateOrder() {
        com.accenture.ws.entity.Order order = ordersRepository.save(new com.accenture.ws.entity.Order("Cafe Latte",3.5,true));
        long id = (long) 1.0;
        ordersRepository.findById(id);
        Assertions.assertThat(order.getId()).isGreaterThan(0);
    }
}